using ClosedXML.Excel;
using ReportGenerator.Core.Models;
using System.Data;

namespace ReportGenerator.Core.Exporters;

public sealed class ExcelExporter
{
    public async Task ExportAsync(DataTable data, ReportConfig config, CancellationToken ct = default)
    {
        await Task.Run(() =>
        {
            using var workbook = new XLWorkbook();
            var worksheet = workbook.Worksheets.Add(config.Title ?? "Report");

            worksheet.Cell(1, 1).Value = config.Title ?? "Report";
            worksheet.Cell(1, 1).Style.Font.Bold = true;
            worksheet.Cell(1, 1).Style.Font.FontSize = 16;
            worksheet.Range(1, 1, 1, data.Columns.Count).Merge();

            for (int col = 0; col < data.Columns.Count; col++)
            {
                worksheet.Cell(3, col + 1).Value = data.Columns[col].ColumnName;
                worksheet.Cell(3, col + 1).Style.Font.Bold = true;
                worksheet.Cell(3, col + 1).Style.Fill.BackgroundColor = XLColor.LightGray;
            }

            for (int row = 0; row < data.Rows.Count; row++)
            {
                for (int col = 0; col < data.Columns.Count; col++)
                {
                    var value = data.Rows[row][col];
                    worksheet.Cell(row + 4, col + 1).Value = value is DBNull ? string.Empty : value.ToString();
                }
            }

            var tableRange = worksheet.Range(3, 1, data.Rows.Count + 3, data.Columns.Count);
            tableRange.Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
            tableRange.Style.Border.InsideBorder = XLBorderStyleValues.Thin;

            int chartRowOffset = data.Rows.Count + 6;
            foreach (var chartDef in config.Charts)
            {
                AddChartData(worksheet, data, chartDef, chartRowOffset);
                chartRowOffset += 22;
            }

            worksheet.Columns().AdjustToContents();
            workbook.SaveAs(config.OutputPath);
        }, ct);
    }

    private void AddChartData(IXLWorksheet worksheet, DataTable data, ChartDefinition chartDef, int startRow)
    {
        var columnNames = data.Columns.Cast<DataColumn>().Select(c => c.ColumnName).ToArray();
        var xCol = Array.IndexOf(columnNames, chartDef.XAxisColumn);
        var yCol = Array.IndexOf(columnNames, chartDef.YAxisColumn);

        if (xCol < 0 || yCol < 0) return;

        worksheet.Cell(startRow, 1).Value = $"[График: {chartDef.Title}]";
        worksheet.Cell(startRow, 1).Style.Font.Bold = true;
        worksheet.Cell(startRow, 1).Style.Font.FontSize = 12;
        worksheet.Cell(startRow + 1, 1).Value = $"Тип: {chartDef.Type}, X: {chartDef.XAxisColumn}, Y: {chartDef.YAxisColumn}";
        worksheet.Cell(startRow + 1, 1).Style.Font.Italic = true;

        var sum = 0.0;
        var count = 0;
        for (int i = 0; i < data.Rows.Count; i++)
        {
            var yRaw = data.Rows[i][yCol]?.ToString() ?? "0";
            if (double.TryParse(yRaw, out var yVal))
            {
                sum += yVal;
                count++;
            }
        }

        worksheet.Cell(startRow + 2, 1).Value = $"Всего записей: {count}, Сумма: {sum:F2}";
        worksheet.Cell(startRow + 3, 1).Value = $"Среднее: {(count > 0 ? sum / count : 0):F2}";
    }
}
