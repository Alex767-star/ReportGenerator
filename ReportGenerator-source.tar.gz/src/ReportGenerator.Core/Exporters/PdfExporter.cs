using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;
using ReportGenerator.Core.Models;
using System.Data;

namespace ReportGenerator.Core.Exporters;

public sealed class PdfExporter
{
    public async Task ExportAsync(DataTable data, ReportConfig config, CancellationToken ct = default)
    {
        await Task.Run(() =>
        {
            QuestPDF.Settings.License = LicenseType.Community;

            Document.Create(container =>
            {
                container.Page(page =>
                {
                    page.Size(PageSizes.A4.Landscape());
                    page.Margin(20);
                    page.DefaultTextStyle(x => x.FontSize(8));

                    page.Header().Element(c => ComposeHeader(c, config));
                    page.Content().Element(c => ComposeContent(c, data, config));
                    page.Footer().AlignCenter().Text(text =>
                    {
                        text.Span("Страница ");
                        text.CurrentPageNumber();
                        text.Span(" из ");
                        text.TotalPages();
                    });
                });
            }).GeneratePdf(config.OutputPath);
        }, ct);
    }

    private void ComposeHeader(IContainer container, ReportConfig config)
    {
        container.Column(col =>
        {
            col.Item().Text(config.Title ?? "Отчет")
                .FontSize(16).Bold().FontColor(Colors.Blue.Darken3);
            col.Item().Text(DateTime.Now.ToString("dd.MM.yyyy HH:mm"))
                .FontSize(7).FontColor(Colors.Grey.Medium);
        });
    }

    private void ComposeContent(IContainer container, DataTable data, ReportConfig config)
    {
        container.Column(col =>
        {
            col.Item().PaddingVertical(5).Element(c => CreateTable(c, data));

            foreach (var chart in config.Charts)
            {
                col.Item().PageBreak();
                col.Item().Text(chart.Title).FontSize(12).Bold();
                col.Item().PaddingVertical(5).Element(c => CreateChartPlaceholder(c, chart, data));
            }
        });
    }

    private void CreateTable(IContainer container, DataTable data)
    {
        var columnWidths = CalculateColumnWidths(data);

        container.Table(table =>
        {
            table.ColumnsDefinition(columns =>
            {
                foreach (var width in columnWidths)
                {
                    columns.ConstantColumn(width);
                }
            });

            table.Header(header =>
            {
                foreach (DataColumn col in data.Columns)
                {
                    header.Cell()
                        .Background(Colors.Grey.Lighten2)
                        .Padding(3).Text(col.ColumnName).Bold().FontSize(7);
                }
            });

            foreach (DataRow row in data.Rows)
            {
                foreach (var item in row.ItemArray)
                {
                    table.Cell()
                        .BorderBottom(0.5f).BorderColor(Colors.Grey.Lighten3)
                        .Padding(3).Text(item?.ToString() ?? string.Empty).FontSize(7);
                }
            }
        });
    }

    private float[] CalculateColumnWidths(DataTable data)
    {
        const float pageWidth = 780f;
        const float minColumnWidth = 60f;
        const float maxColumnWidth = 200f;
        var columnCount = data.Columns.Count;

        var widths = new float[columnCount];
        var samples = Math.Min(100, data.Rows.Count);

        for (int col = 0; col < columnCount; col++)
        {
            var maxLength = data.Columns[col].ColumnName.Length;

            for (int row = 0; row < samples; row++)
            {
                var val = data.Rows[row][col]?.ToString() ?? string.Empty;
                maxLength = Math.Max(maxLength, val.Length);
            }

            widths[col] = Math.Clamp(maxLength * 5f + 10f, minColumnWidth, maxColumnWidth);
        }

        var totalWidth = widths.Sum();
        if (totalWidth > pageWidth)
        {
            var scale = pageWidth / totalWidth;
            for (int i = 0; i < widths.Length; i++)
            {
                widths[i] = Math.Max(widths[i] * scale, 40f);
            }
        }

        return widths;
    }

    private void CreateChartPlaceholder(IContainer container, ChartDefinition chart, DataTable data)
    {
        var xCol = data.Columns.IndexOf(chart.XAxisColumn);
        var yCol = data.Columns.IndexOf(chart.YAxisColumn);

        container.Column(col =>
        {
            col.Item().Text($"Тип графика: {chart.Type}").FontSize(7).FontColor(Colors.Grey.Medium);
            col.Item().Text($"Данные: {chart.XAxisColumn} / {chart.YAxisColumn}").FontSize(7);
            col.Item().PaddingVertical(3).LineHorizontal(0.5f);

            var statsRows = data.Rows.Cast<DataRow>()
                .Select(r => $"{r[xCol]}: {r[yCol]}")
                .Take(15);

            foreach (var stat in statsRows)
            {
                col.Item().Text(stat).FontSize(7);
            }
        });
    }
}
