using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;
using ReportGenerator.Core.Models;
using System.Data;

namespace ReportGenerator.Core.Exporters;

public sealed class PdfExporter
{
    public async Task ExportAsync(DataTable data, ReportConfig config, CancellationToken ct = default)
    {
        await Task.Run(() =>
        {
            QuestPDF.Settings.License = LicenseType.Community;

            Document.Create(container =>
            {
                container.Page(page =>
                {
                    page.Size(PageSizes.A4);
                    page.Margin(30);
                    page.DefaultTextStyle(x => x.FontSize(10));

                    page.Header().Element(c => ComposeHeader(c, config));
                    page.Content().Element(c => ComposeContent(c, data, config));
                    page.Footer().AlignCenter().Text(text =>
                    {
                        text.Span("Страница ");
                        text.CurrentPageNumber();
                        text.Span(" из ");
                        text.TotalPages();
                    });
                });
            }).GeneratePdf(config.OutputPath);
        }, ct);
    }

    private void ComposeHeader(IContainer container, ReportConfig config)
    {
        container.Column(col =>
        {
            col.Item().Text(config.Title ?? "Отчет")
                .FontSize(20).Bold().FontColor(Colors.Blue.Darken3);
            col.Item().Text(DateTime.Now.ToString("dd.MM.yyyy HH:mm"))
                .FontSize(9).FontColor(Colors.Grey.Medium);
        });
    }

    private void ComposeContent(IContainer container, DataTable data, ReportConfig config)
    {
        container.Column(col =>
        {
            col.Item().PaddingVertical(10).Element(c => CreateTable(c, data));

            foreach (var chart in config.Charts)
            {
                col.Item().PageBreak();
                col.Item().Text(chart.Title).FontSize(14).Bold();
                col.Item().PaddingVertical(10).Element(c => CreateChartPlaceholder(c, chart, data));
            }
        });
    }

    private void CreateTable(IContainer container, DataTable data)
    {
        container.Table(table =>
        {
            table.ColumnsDefinition(columns =>
            {
                foreach (DataColumn _ in data.Columns)
                    columns.RelativeColumn();
            });

            table.Header(header =>
            {
                foreach (DataColumn col in data.Columns)
                {
                    header.Cell().Background(Colors.Grey.Lighten2)
                        .Padding(4).Text(col.ColumnName).Bold();
                }
            });

            foreach (DataRow row in data.Rows)
            {
                foreach (var item in row.ItemArray)
                {
                    table.Cell().BorderBottom(1).BorderColor(Colors.Grey.Lighten3)
                        .Padding(4).Text(item?.ToString() ?? string.Empty);
                }
            }
        });
    }

    private void CreateChartPlaceholder(IContainer container, ChartDefinition chart, DataTable data)
    {
        var xCol = data.Columns.IndexOf(chart.XAxisColumn);
        var yCol = data.Columns.IndexOf(chart.YAxisColumn);

        container.Column(col =>
        {
            col.Item().Text($"Тип графика: {chart.Type}").FontSize(8).FontColor(Colors.Grey.Medium);
            col.Item().Text($"Данные: {chart.XAxisColumn} / {chart.YAxisColumn}").FontSize(8);

            var statsRows = data.Rows.Cast<DataRow>()
                .Select(r => $"{r[xCol]}: {r[yCol]}")
                .Take(10);

            foreach (var stat in statsRows)
            {
                col.Item().Text(stat).FontSize(9);
            }
        });
    }
}
