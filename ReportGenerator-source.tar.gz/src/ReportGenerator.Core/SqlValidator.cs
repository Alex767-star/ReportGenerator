namespace ReportGenerator.Core;

public static class SqlValidator
{
    private static readonly HashSet<string> DangerousKeywords = new(StringComparer.OrdinalIgnoreCase)
    {
        "DROP", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "ALTER",
        "CREATE", "EXEC", "EXECUTE", "MERGE", "REPLACE", "GRANT", "REVOKE"
    };

    public static bool IsReadOnlyQuery(string sql, out string? blockedKeyword)
    {
        var tokens = sql.Split(new[] { ' ', '\t', '\n', '\r', ';' }, StringSplitOptions.RemoveEmptyEntries);

        foreach (var token in tokens)
        {
            var cleanToken = token.Trim().ToUpperInvariant();
            if (DangerousKeywords.Contains(cleanToken))
            {
                blockedKeyword = cleanToken;
                return false;
            }
        }

        blockedKeyword = null;
        return true;
    }
}
