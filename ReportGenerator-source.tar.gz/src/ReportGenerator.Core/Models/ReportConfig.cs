namespace ReportGenerator.Core.Models;

public sealed class ReportConfig
{
    public string ConnectionString { get; init; } = string.Empty;
    public string SqlQuery { get; init; } = string.Empty;
    public string OutputPath { get; init; } = string.Empty;
    public ReportFormat Format { get; init; } = ReportFormat.Excel;
    public string? Title { get; init; }
    public List<ChartDefinition> Charts { get; init; } = new();
    public Dictionary<string, string> Parameters { get; init; } = new();
}

public sealed class ChartDefinition
{
    public string Title { get; init; } = string.Empty;
    public ChartType Type { get; init; }
    public string XAxisColumn { get; init; } = string.Empty;
    public string YAxisColumn { get; init; } = string.Empty;
}

public enum ReportFormat
{
    Excel,
    Pdf
}

public enum ChartType
{
    Bar,
    Line,
    Pie
}
