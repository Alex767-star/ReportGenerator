using System.Text.Json;
using ReportGenerator.Core.Models;

namespace ReportGenerator.Core;

public static class ConfigurationLoader
{
    public static ReportConfig LoadFromFile(string configPath)
    {
        var json = File.ReadAllText(configPath);
        var options = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        };
        return JsonSerializer.Deserialize<ReportConfig>(json, options)
            ?? throw new InvalidOperationException("Failed to load configuration");
    }

    public static ReportConfig CreateFromArguments(
        string connectionString,
        string sqlQuery,
        string outputPath,
        string format,
        string? title = null)
    {
        return new ReportConfig
        {
            ConnectionString = connectionString,
            SqlQuery = sqlQuery,
            OutputPath = outputPath,
            Format = format.ToLowerInvariant() switch
            {
                "pdf" => ReportFormat.Pdf,
                "excel" => ReportFormat.Excel,
                _ => throw new ArgumentException($"Unsupported format: {format}")
            },
            Title = title
        };
    }
}
