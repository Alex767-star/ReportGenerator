using System.Data;
using Dapper;
using Npgsql;

namespace ReportGenerator.Core.Data;

public sealed class DatabaseProvider : IDisposable
{
    private readonly NpgsqlConnection _connection;
    private bool _disposed;

    public DatabaseProvider(string connectionString)
    {
        _connection = new NpgsqlConnection(connectionString);
    }

    public async Task<IReadOnlyList<dynamic>> ExecuteQueryAsync(string sql, Dictionary<string, string>? parameters = null)
    {
        var dynamicParams = new DynamicParameters();
        if (parameters is not null)
        {
            foreach (var (key, value) in parameters)
            {
                dynamicParams.Add(key, value);
            }
        }

        if (_connection.State != ConnectionState.Open)
            await _connection.OpenAsync();

        var result = await _connection.QueryAsync(sql, dynamicParams);
        return result.AsList();
    }

    public async Task<DataTable> ExecuteQueryAsDataTableAsync(string sql, Dictionary<string, string>? parameters = null)
    {
        var data = await ExecuteQueryAsync(sql, parameters);
        var rows = data.ToList();
        
        if (rows.Count == 0)
            return new DataTable();

        var table = new DataTable();
        var first = (IDictionary<string, object>)rows[0];
        
        foreach (var key in first.Keys)
        {
            table.Columns.Add(key, first[key]?.GetType() ?? typeof(string));
        }

        foreach (var row in rows)
        {
            var dict = (IDictionary<string, object>)row;
            var dataRow = table.NewRow();
            foreach (var key in dict.Keys)
            {
                dataRow[key] = dict[key] ?? DBNull.Value;
            }
            table.Rows.Add(dataRow);
        }

        return table;
    }

    public void Dispose()
    {
        if (!_disposed)
        {
            _connection.Dispose();
            _disposed = true;
        }
    }
}
