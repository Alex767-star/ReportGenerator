using ReportGenerator.Core.Data;
using ReportGenerator.Core.Exporters;
using ReportGenerator.Core.Models;

namespace ReportGenerator.Core;

public sealed class ReportEngine : IDisposable
{
    private readonly string _connectionString;
    private readonly ExcelExporter _excelExporter = new();
    private readonly PdfExporter _pdfExporter = new();
    private bool _disposed;

    public ReportEngine(string connectionString)
    {
        _connectionString = connectionString;
    }

    public async Task<ReportResult> GenerateAsync(ReportConfig config, CancellationToken ct = default)
    {
        var startTime = DateTime.UtcNow;

        using var db = new DatabaseProvider(config.ConnectionString);
        var data = await db.ExecuteQueryAsDataTableAsync(config.SqlQuery, config.Parameters);

        switch (config.Format)
        {
            case ReportFormat.Excel:
                await _excelExporter.ExportAsync(data, config, ct);
                break;
            case ReportFormat.Pdf:
                await _pdfExporter.ExportAsync(data, config, ct);
                break;
        }

        return new ReportResult
        {
            FilePath = config.OutputPath,
            RowsCount = data.Rows.Count,
            GenerationTime = DateTime.UtcNow - startTime,
            Format = config.Format
        };
    }

    public void Dispose()
    {
        if (!_disposed)
        {
            _disposed = true;
        }
    }
}

public sealed class ReportResult
{
    public string FilePath { get; init; } = string.Empty;
    public int RowsCount { get; init; }
    public TimeSpan GenerationTime { get; init; }
    public ReportFormat Format { get; init; }
}
