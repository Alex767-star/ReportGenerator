using System.CommandLine;
using System.Diagnostics;
using ReportGenerator.Core;
using ReportGenerator.Core.Models;

namespace ReportGenerator.Cli;

class Program
{
    static async Task<int> Main(string[] args)
    {
        var connStringOption = new Option<string>(
            aliases: new[] { "--connection", "-c" },
            description: "PostgreSQL connection string")
        { IsRequired = true };

        var queryOption = new Option<string>(
            aliases: new[] { "--query", "-q" },
            description: "SQL query to execute")
        { IsRequired = true };

        var outputOption = new Option<string>(
            aliases: new[] { "--output", "-o" },
            description: "Output file path")
        { IsRequired = true };

        var formatOption = new Option<string>(
            aliases: new[] { "--format", "-f" },
            description: "Output format (excel/pdf)",
            getDefaultValue: () => "excel");

        var titleOption = new Option<string?>(
            aliases: new[] { "--title", "-t" },
            description: "Report title");

        var configFileOption = new Option<string?>(
            aliases: new[] { "--config", "-cfg" },
            description: "Path to JSON configuration file");

        var verboseOption = new Option<bool>(
            aliases: new[] { "--verbose", "-v" },
            description: "Enable verbose output");

        var rootCommand = new RootCommand("Advanced Report Generator - PostgreSQL to Excel/PDF");
        rootCommand.AddOption(connStringOption);
        rootCommand.AddOption(queryOption);
        rootCommand.AddOption(outputOption);
        rootCommand.AddOption(formatOption);
        rootCommand.AddOption(titleOption);
        rootCommand.AddOption(configFileOption);
        rootCommand.AddOption(verboseOption);

        rootCommand.SetHandler(async (context) =>
        {
            var connString = context.ParseResult.GetValueForOption(connStringOption)!;
            var query = context.ParseResult.GetValueForOption(queryOption)!;
            var output = context.ParseResult.GetValueForOption(outputOption)!;
            var format = context.ParseResult.GetValueForOption(formatOption)!;
            var title = context.ParseResult.GetValueForOption(titleOption);
            var configFile = context.ParseResult.GetValueForOption(configFileOption);
            var verbose = context.ParseResult.GetValueForOption(verboseOption);

            ReportConfig config;

            if (!string.IsNullOrEmpty(configFile) && File.Exists(configFile))
            {
                config = ConfigurationLoader.LoadFromFile(configFile);
            }
            else
            {
                config = ConfigurationLoader.CreateFromArguments(
                    connString, query, output, format, title);
            }

            var sw = Stopwatch.StartNew();
            using var engine = new ReportEngine(config.ConnectionString);

            try
            {
                if (verbose)
                    Console.WriteLine("Подключение к БД... Выполнение запроса...");

                var result = await engine.GenerateAsync(config);

                sw.Stop();

                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("✅ Отчет успешно сгенерирован!");
                Console.ResetColor();
                Console.WriteLine($"   Файл: {result.FilePath}");
                Console.WriteLine($"   Формат: {result.Format}");
                Console.WriteLine($"   Строк: {result.RowsCount}");
                Console.WriteLine($"   Время генерации: {result.GenerationTime.TotalSeconds:F2} сек");

                if (verbose)
                {
                    Console.WriteLine($"   Общее время выполнения: {sw.Elapsed.TotalSeconds:F2} сек");
                }

                context.ExitCode = 0;
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"❌ Ошибка: {ex.Message}");
                Console.ResetColor();

                if (verbose)
                    Console.WriteLine(ex.StackTrace);

                context.ExitCode = 1;
            }
        });

        return await rootCommand.InvokeAsync(args);
    }
}
