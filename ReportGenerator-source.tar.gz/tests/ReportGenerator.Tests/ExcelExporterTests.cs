using ReportGenerator.Core.Exporters;
using ReportGenerator.Core.Models;
using System.Data;
using Xunit;

namespace ReportGenerator.Tests;

public class ExcelExporterTests
{
    [Fact]
    public async Task Export_ShouldCreateExcelFile()
    {
        var data = new DataTable();
        data.Columns.Add("Name", typeof(string));
        data.Columns.Add("Value", typeof(int));
        data.Rows.Add("Item1", 100);
        data.Rows.Add("Item2", 200);

        var config = new ReportConfig
        {
            Title = "Test Report",
            OutputPath = Path.GetTempFileName() + ".xlsx",
            Format = ReportFormat.Excel
        };

        var exporter = new ExcelExporter();
        await exporter.ExportAsync(data, config);

        Assert.True(File.Exists(config.OutputPath));
        File.Delete(config.OutputPath);
    }
}
