using ReportGenerator.Core;
using ReportGenerator.Core.Models;
using System.Text.Json;
using Xunit;

namespace ReportGenerator.Tests;

public class ConfigurationLoaderTests
{
    [Fact]
    public void LoadFromFile_ShouldParseValidJson()
    {
        var json = JsonSerializer.Serialize(new ReportConfig
        {
            ConnectionString = "Host=localhost",
            SqlQuery = "SELECT 1",
            OutputPath = "test.xlsx",
            Format = ReportFormat.Excel
        });

        var tempFile = Path.GetTempFileName();
        File.WriteAllText(tempFile, json);

        var config = ConfigurationLoader.LoadFromFile(tempFile);
        Assert.Equal("Host=localhost", config.ConnectionString);
        Assert.Equal(ReportFormat.Excel, config.Format);

        File.Delete(tempFile);
    }
}
