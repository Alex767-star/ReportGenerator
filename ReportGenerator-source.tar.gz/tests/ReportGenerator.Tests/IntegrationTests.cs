using ReportGenerator.Core;
using ReportGenerator.Core.Models;
using Xunit;

namespace ReportGenerator.Tests;

public class IntegrationTests
{
    [Fact]
    public void SqlValidator_ShouldBlock_DangerousQueries()
    {
        Assert.False(SqlValidator.IsReadOnlyQuery("DROP TABLE users", out var kw1));
        Assert.Equal("DROP", kw1);

        Assert.False(SqlValidator.IsReadOnlyQuery("INSERT INTO logs VALUES (1)", out var kw2));
        Assert.Equal("INSERT", kw2);

        Assert.False(SqlValidator.IsReadOnlyQuery("DELETE FROM temp", out var kw3));
        Assert.Equal("DELETE", kw3);

        Assert.False(SqlValidator.IsReadOnlyQuery("UPDATE accounts SET balance=0", out var kw4));
        Assert.Equal("UPDATE", kw4);

        Assert.True(SqlValidator.IsReadOnlyQuery("SELECT * FROM users", out _));
        Assert.True(SqlValidator.IsReadOnlyQuery("SELECT COUNT(*) FROM orders", out _));
        Assert.True(SqlValidator.IsReadOnlyQuery("WITH cte AS (SELECT 1) SELECT * FROM cte", out _));
    }

    [Fact]
    public void SqlValidator_ShouldDetect_MultipleKeywords()
    {
        var complexQuery = "SELECT * FROM users; DROP TABLE users;";
        Assert.False(SqlValidator.IsReadOnlyQuery(complexQuery, out var kw));
        Assert.Equal("DROP", kw);
    }
}
